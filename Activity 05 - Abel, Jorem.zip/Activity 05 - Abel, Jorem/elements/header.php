</div>
   
    
   <!--   <div class="search-box"> 
       <input class="search-text"type="text" name=" " placeholder="Type to search">
       <a class="search-btn" href="#">
          <img src="Assets/search.png" alt="search" height="40px" width="40px">
           
       </a>
       </div> -->
       
       
<div id=header>  
  <a href="Nostrum.html"> <img src="Assets/Nostrumlogo.png" alt="nostrum"></a>    
</div>