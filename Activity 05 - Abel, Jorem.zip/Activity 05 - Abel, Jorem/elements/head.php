<head>
      <title> Welcome to Nostrum Official Website</title>
      <link rel="stylesheet" type="text/css" href="stylesheet.css">
      <link rel="stylesheet" type="text/css" href="media screens.css">
   </head>