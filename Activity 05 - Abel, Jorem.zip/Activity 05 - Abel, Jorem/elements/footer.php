<div class="text7">
                  <p><?= $footer["line1"]?></p>
              </div>
               <div class="text8">
                  <p><?= $footer["line2"]?></p>
              </div>
            
               <div id="wanwan">
                <img src="Assets/iphone7.png" alt="iphone7" height="223" width="267">
                    <div class="text12">
                  <p><?= $footer["line3"]?></p>
                  </div>
                     
                     </div>
                     <div class="text9">
                  <p><?= $footer["line4"]?></p>
                  <div class="text10">
                  <p><?= $footer["line4"]?></p>
                  </div>
                   <div class="text11">
                  <p><?= $footer["line4"]?></p>
                  </div>
              </div> 
                     <div id="phone">
                         <img src="Assets/phone.png" alt="phone" height="300" width="150">
                     </div>
                    
            <div id="wifi2">
               <img src="Assets/wifi.png" alt="wifi2" width="82" height="82">
                </div>
                <div id="connect2">
                <img src="Assets/connect%202.png" alt="connect2">  
                </div>
                <div id="message2">
                    <img src="Assets/message.png" alt="message">
                </div>
               <div id="loginform"></div>
                 
                 <div id=vert>
                </div>
                
                <div id=tical>
                </div>
                
                <div id="horiz">
                   <div class="text13">
                  <p><?= $form["name1"]?></p>
                  </div>
                    <div class="text14">
                  <p><?= $form["name2"]?></p>
                  </div>
                    
                    
                </div>
                <div id="orange"> </div>
                <div id="blue"> </div>
                
                <div id="search-box">
                   <input class="search-text" type="text" name=" " placeholder="Aperiam">
                   <a class="search-btn" href="Lorem.htm">
                       <img src="Assets/search.png" alt="searchbtn" class="searchbtn" height="40px" width="40px">
                   </a>        
                </div>
                <div id="box">
                     </div>
                     
                     <div class="lorem-ipsum" href="#">
                         <p1><a href="Nostrum.html"><?= $menubar["menu1"]?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </a> </p1> 
                         <p1><a href="Lorem.htm"><?= $menubar["menu2"]?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a> </p1> 
                         <p1><a href="About.html"><?= $menubar["menu3"]?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a> </p1>
                     </div>
                     
                     
                
                
                
             <div>
                 <a href="Google.com"><button class="button1"><?= $button["but1"]?></button>
            </a>
            </div>
              <div>
                 <a href="Google.com"><button class="button2"><?= $button["but2"]?></button>
            </a>
            </div>      
              <div>
                 <a href="Nostrum.html"><button class="button3"><?= $button["but2"]?></button>
            </a>
            </div>
           
            
                     <form>
          
           <input type="text3" name="search" placeholder="Adipiscing">
           <input type="text4" name="search" placeholder="Ex ea commodi">
            
        </form>
        <script>
            document.onreadystatechange=function() {
                if (document.readyState !== "complete"){
                    document.querySelector(
                    "body").style .visibility= "visible";
                    }
                else{
                    document.querySelector(
                    "#loader").style .display="none";
                    document.querySelector(
                    "body") .style .visibility="visible";
                }
            };
       
       
       
       </script>   