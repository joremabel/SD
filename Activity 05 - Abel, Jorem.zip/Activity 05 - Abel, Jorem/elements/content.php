<div>
          <img src="Assets/Skyline.jpg" alt="skyline" class="skyline">
          <img src="Assets/samsunggalaxy.png" alt="Samsung" class="samsung">
          <text1>  <?= $content["line1"]?></text1>
            <text3><?= $content["line2"]?></text3>

          
     </div>
   
     <div id=horizontal1>
      <div class="text4">
          <p><?= $content["line3"]?></p>
      </div>
       <div class="text5">
          <p><?= $content["line3"]?></p>
      </div>
             <div class="text6">
          <p><?= $content["line3"]?></p>
      </div>
      </div>
          <div id="wifi">
              <img src="Assets/wifi%201.png" alt="wifi"> 
        
         </div>  
          
          <div id="connect">
          <img src="Assets/connect%202.png" alt="connect">
             </div>
             
             <div id="message">
         
           <img src="Assets/message.png" alt="message">
          </div>